import React from 'react'
import List from './list';
import './Tab.css'
export default function Tab() {
    return (
        <div className= 'tab'>
            <List align= 'horizontal' itemList = {['App.js', 'Bid.js', 'tender.js', 'index.js', 'shortTender.js', 'Gte.js']}/>
        </div>
    )
}
