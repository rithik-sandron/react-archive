import React from 'react';
import { Route, Switch } from 'react-router-dom';
import Authentication from '../authentication/Authentication';
import Home from '../../Home-page/Home';
import Face from '../../Home-page/Face';
import Editor from '../TextEditor/TextEditor'

function Router() {
    return (
        <div>
            <Switch>
                <Route path="/" exact component={Home} />
                <Route path="/About" component = {Face} />
                <Route path="/SignUp" exact render= {() => <Authentication type='Sign Up'/>} />
                <Route path="/LogIn" render= {() => <Authentication type='Log In'/>} />
                <Route path="/Editor" component={Editor} />
                
                <Route render={() => <h1 className="container">404 Page not found</h1>} />
            </Switch>
        </div>
    );
}
export default Router;