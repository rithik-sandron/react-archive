let crypto = require('crypto');

function aes(input) {
    return crypto.createHash('sha512').update(input).digest('hex');
}

function sha512(input) {
    return crypto.createHash('sha512').update(input).digest('hex');
}

module.exports = {
    sha512, aes
};

