import React, { useState, useContext } from 'react';
import { ThemeContext } from '../App';
import './layout.css';
import List from './individual-components/list';

export default function Layout() {

    const [theme] = useContext(ThemeContext);

    const [list] = useState(['App.js', 'Bid.js', 'tender.js', 'index.js', 'shortTender.js', 'Gte.js']);
    const editorcolor = theme.currentTheme === theme.light ? theme.editorColor.light : theme.editorColor.dark;
    const trayColor = theme.currentTheme === theme.light ? theme.trayColor.light : theme.trayColor.dark;
    const color = theme.currentTheme === theme.light ? theme.darkColor : theme.lightColor;
    return (
        <div className="layout">
            <div id="explorer" style={{ backgroundColor: trayColor, color: color }}>
                <ul id="explorerItems" style={{ margin: "8px", backgroundColor: trayColor, color: color }}>
                    <List itemList={list} />
                </ul>
            </div>
            <div id="editor" style={{ backgroundColor: editorcolor, color: color }}>
            </div>
        </div>
    )
}
