import React, { useState, useEffect } from 'react';
import './App.css';
import Footer from './components/footer';
import Header from './components/header';
import Layout from './components/layout';

export const ThemeContext = React.createContext();




function App() {
  const [theme, setTheme] = useState({
    currentTheme: 'Light',
    light: 'Light',
    dark: 'Dark',
    lightColor: '#fff',
    darkColor: 'rgb(78, 78, 78)',
    header: { light: '#dedede', dark: 'rgb(64, 64, 65)' },
    trayColor: { light: 'rgb(233, 233, 233)', dark: 'rgb(49, 48, 48)' },
    editorColor: { light: '#fff', dark: '#222' }
  })
 
  useEffect(() => {
    fetch("/session").then(res => {
	console.log(res);
   });

  
  return (

    <div className="App">
      <ThemeContext.Provider value={[theme, setTheme]}>

        {/* <div id='talk' className='talk'>(o<span className='App-logo'>_</span>o)</div> */}
        <Header />
        <div className="App-header"><Layout /></div>
        <Footer />
      </ThemeContext.Provider>
    </div>
  );
}

export default App;
