import React from 'react'
import './Nav.css'
import { NavLink } from 'react-router-dom'

export default function Nav() {
    
    return (
        <div className="Nav">
           
            <ul>
                <li><NavLink to="/About">About</NavLink></li>
                <li>Products</li>
                <li>Privacy</li>
                <li><NavLink to="/LogIn">Log In</NavLink></li>
                <li><NavLink to="/SignUp">Sign Up</NavLink></li>
                <li><NavLink to="/Editor">Editor</NavLink></li>
               
            </ul>
        </div>
    )
}

