import React, { Component } from 'react'

export class Poster extends Component {
    render() {
        return (
            <div>
                <h1>he</h1>
            </div>
        )
    }
}

export default Poster
