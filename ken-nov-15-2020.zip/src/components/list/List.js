import React, { useEffect, useState } from 'react'
import './List.css';
import axios from 'axios';

export default function List(props) {
    const [list, setList] = useState([]);

    useEffect(() => {
        axios.get('/getUsers').then(res => {
            setList(res.data)
        })
    }, []);

    return (
        <div className="list-container">
            {list.map(x => <div className="List" key={x._id}>
                <h2>{x.email}</h2>
                <p>{x.password}</p>
            </div>)}
            <a href="/"><h3 id="archieves">More stories</h3></a>
        </div>
    )
}
