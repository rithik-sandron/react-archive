import './App.css';
import Router from './components/Router/Router'
import { BrowserRouter } from 'react-router-dom';
import { useState, useEffect } from 'react';
import axios from 'axios';

function App() {

  const [__session, set__session] = useState('');

  useEffect(() => {
    axios.get('/check').then(res => {
      set__session(res.data);
    });
  }, []);

  return (

    <BrowserRouter>
      <div id="show" className="App" >
        <span id='floater'>session id: {__session}</span>
        <Router />
      </div>
     {/* style={{display: "none"}} {document.getElementById("show").style.display = "block"} */}
    </BrowserRouter>
  );
}

export default App;
