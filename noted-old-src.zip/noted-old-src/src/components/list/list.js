import React, { useState, useEffect, useContext } from 'react';
import { ThemeContext } from '../../App';
import './list.css';
import TextEditor from '../TextEditor/TextEditor';
import expand from '../../assets/expand.svg';
import dots from '../../assets/dots.svg';

export default function List() {

    const [theme] = useContext(ThemeContext);
    const editorcolor = theme.currentTheme === theme.light ? theme.editorColor.light : theme.editorColor.dark;
    const trayColor = theme.currentTheme === theme.light ? theme.trayColor.light : theme.trayColor.dark;
    const color = theme.currentTheme === theme.light ? theme.darkColor : theme.lightColor;


    const [noteList, setNoteList] = useState(localStorage ? Object.keys(localStorage)
        .map(i => { return { id: i, date: JSON.parse(localStorage[i]).date, data: JSON.parse(localStorage[i]).data } }) : []);

    const [searchResult, setSearchResult] = useState({ searchText: '', notes: [] });

    const [preview, setPreview] = useState(null);

    let noteData;
    const [svgStyle, setSvgStyle] = useState('expandSvg');

    useEffect(() => {
        if (localStorage)
            localStorage.setItem('0', JSON.stringify({ date: new Intl.DateTimeFormat('en-US', options).format(new Date()), data: '# welcome' }));
    });

    let classes = ['list', 'seperator'];

    let options = { dateStyle: 'full', timeStyle: 'short' };

    function addNote() {
        const createdDate = new Intl.DateTimeFormat('en-US', options).format(new Date());
        const newNote = { id: localStorage.length, date: createdDate, data: '' };
        let prevNotes = noteList;
        prevNotes.unshift(newNote);
        setNoteList([...prevNotes]);
        localStorage.setItem(localStorage.length, JSON.stringify({ date: createdDate, data: '' }));
        openNote(newNote);
    }

    function openNote(note) {
        setPreview(<TextEditor note={note} onEdit={editNote} />);
    }

    function editNote(id, text) {
        // localStorage.setItem(id, JSON.stringify({ date: new Intl.DateTimeFormat('en-US', options).format(new Date()), data: text }));
        // setNoteList(Object.keys(localStorage).map(i => { return { id: i, date: JSON.parse(localStorage[i]).date, data: JSON.parse(localStorage[i]).data } }));
        const updatedDate = new Intl.DateTimeFormat('en-US', options).format(new Date());
        const updatedNote = { id: id, date: updatedDate, data: text };
        let prevNotes = noteList;
        prevNotes[prevNotes.indexOf(prevNotes.find(x => x.id === id))] = updatedNote;
        setNoteList([...prevNotes]);
        localStorage.setItem(id, JSON.stringify({ date: updatedDate, data: text }));
        openNote(updatedNote);
    }

    function search(event) {
        let filteredList = noteList.filter(x => x.data.toLowerCase().includes(event.target.value.toString().toLowerCase()));
        filteredList.forEach(x => x.isExpanded = false);
        setSearchResult({ searchText: event.target.value, notes: [...filteredList] })
    }

    function accordion(index) {
        let prevSearchResult = searchResult;
        let prevNote = prevSearchResult.notes[index];
        prevNote.isExpanded = !prevNote.isExpanded;
        prevSearchResult.notes[index] = prevNote;
        setSearchResult({ searchText: prevSearchResult.searchResult, notes: [...prevSearchResult.notes] });
        setSvgStyle(svgStyle === 'expandSvg' ? 'closeSvg' : 'expandSvg');
    }

    function setData(data) {
        noteData = data;
    }

    function deleteNote(index, id) {
        let prevNoteList = noteList;
        prevNoteList.splice(index, 1);
        localStorage.removeItem(id);
        setNoteList([...prevNoteList]);
        setPreview(null);
    }

    // function exportNotes() {
    //     let fileArray = [];
    //     noteList.forEach(x => {
    //         let fileName = `note_${x.id}.md`;
    //         var file = new File(Buffer.from(x.data), fileName, {type: 'text/plain'});
    //         fileArray.push(file);
    //     });
    //     console.log(fileArray)
    // }

    return (
        <div className='grid'>
            <div id='contain'>
                <div className='divide'>
                    <input className='transparent' placeholder='Search' onChange={search} />
                    <button className='button' onClick={addNote}> + </button>
                </div>
                <div className='wrapper'>
                    {localStorage.length > 0 ?
                        searchResult.searchText !== "" ? searchResult.notes.length <= 0 ?
                            <li>No results found. Review your search</li> :
                            searchResult.notes.map(x => {
                                if (searchResult.notes.indexOf(x) === searchResult.notes.length - 1) classes.pop();
                                setData(x.data.substring(x.data.indexOf(searchResult.searchText)))
                                return (
                                    <li className={classes.join(' ')} key={x.id}>
                                        {noteData.length > 48 ? <img id={svgStyle} src={expand} alt='' onClick={() => accordion(searchResult.notes.indexOf(x))} /> : null}
                                        {x.isExpanded ?
                                            <span id='searchResult' onClick={() => openNote(x)}>{noteData}</span> :
                                            <span id='searchResult' onClick={() => openNote(x)}>{noteData.substring(noteData.indexOf(searchResult.searchText), 48)}</span>}
                                        <span id='date'>{x.date}</span>
                                    </li>
                                );
                            })
                            :
                            noteList.map(x => {
                                if (noteList.indexOf(x) === noteList.length - 1) classes.pop();
                                return (
                                    <li className={classes.join(' ')} key={x.id}>
                                        <span style={{ fontSize: '16px' }} onClick={() => openNote(x)}>{x.data.substring(0, 48)}</span>
                                        <span onClick={() => deleteNote(noteList.indexOf(x), x.id)}>
                                            <img id='dots' src={dots} alt='' />
                                        </span>
                                        <span id='date'>{x.date}</span>
                                    </li>
                                );
                            }) : null}
                </div>
            </div>
            {preview}
        </div>


    );
};