import React from 'react';
import PropTypes from 'prop-types';
import './list.css';

export default function list(props) {
    if (!Array.isArray(props.itemList)) return null;
    const alignStyle = props.align === 'horizontal' ? { display: 'inline' } : null;
    return (
        <div className='list'>
            <ul id='list-group'>
                {props.itemList.map((x, i) => {
                    return <li id='list-item' key={i} style={alignStyle}>{x}</li>
                })}
            </ul>
        </div>
    )
}

list.propTypes = {
    itemList: PropTypes.array.isRequired,
    align: PropTypes.string
};

list.defaultProps = {
    itemList: ['Please provide a array to display'],
    align: 'vertical'
} 
