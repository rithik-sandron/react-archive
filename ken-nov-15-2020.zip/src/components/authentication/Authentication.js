import React, { useState } from 'react';
import './Authentication.css';
import '../../App.css';
import axios from 'axios';
import { sha512 } from '../utilities/utility';
// import { useHistory } from 'react-router-dom';

export default function Authentication(props) {

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [logged, setLogged] = useState(false);
    // const history = useHistory();

    function emailChange(e) {
        setEmail(e.target.value)
    }

    function passwordChange(e) {
        setPassword(e.target.value);
    }

    // function redirectToHome() {
    //     history.push('/', { isAuth: true });
    // }

    function handleSubmit(e) {
        e.preventDefault();
        const hashedPass = sha512(password);
        axios.post('/signup', { email: email, password: hashedPass }).then(res => {
            if (res.data !== 'success') return 'something went wrong try again';
            else setLogged(true);
        });

    }

    return (
        <div className='container'>

            <form className="Auth" onSubmit={handleSubmit}>
                <h1>{props.type}</h1>
                {logged ?<span id='success'>Account created successfully.</span> : null}
                <input placeholder="Email" type="email" onChange={emailChange} value={email} />
                <input placeholder="Password" type="password" onChange={passwordChange} value={password} />

                <button>{props.type}</button>


            </form>
        </div>
    )
}
