import React, { Component } from 'react'
import './Cards.css'

export class Cards extends Component {
    render() {
        return (
            <div className="Cards">
                {/* section 1 */}
                <div className="big">
                </div>
                {/*
                <div className="row">
                    <div className="col">
                        <div className="small" />
                    </div>
                    <div className="col">
                        <div className="small" />
                    </div>
                </div> */}
            </div>
        )
    }
}

export default Cards
