import React from 'react';
import './Plans.css';

export default function Plans() {
    return (
        <div className='plans'>
            <div id='individual-section'>
                <span>99 $</span>
                <hr id='head' />
                <span id='type'>Bikes and scooters</span>
                <ul id='services'>
                    <li>water beam</li>
                    <li>foam cleaning</li>
                    <li>oil coating</li>
                </ul>
            </div>
            <div id='individual-section'>
                <span>249 $</span>
                <hr id='head' />
                <span id='type'>Hatchback type cars</span>
                <ul id='services'>
                    <li>water beam</li>
                    <li>foam cleaning</li>
                    <li>oil coating</li>
                </ul>
            </div>
            <div id='individual-section'>
                <span>299 $</span>
                <hr id='head' />
                <span id='type'>Sedan type cars</span>
                <ul id='services'>
                    <li>water beam</li>
                    <li>foam cleaning</li>
                    <li>oil coating</li>
                </ul></div>
        </div>
    )
}
