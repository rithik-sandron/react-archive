export default function content(props) {
    return (<div className='content'> {props.children} </div>);
}