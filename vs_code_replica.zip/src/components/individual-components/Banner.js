import React from 'react';
import './Banner.css';
import Form from './Form';

export default function Banner() {
    return (
        <div className = 'banner'>
            <Form />
        </div>
    )
}
