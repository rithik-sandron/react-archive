import React, { Component } from 'react';
import './TextEditor.css'
import marked from 'marked';
import expand from '../../assets/expand.svg';

class TextEditor extends Component {

    constructor(props) {
        super(props);
        this.state = {
            note: this.props.note,
            height: '',
            toggle: false
        }
    }

    componentDidUpdate(prevProps) {
        if (this.props.note !== prevProps.note) {
            this.setState({ note: this.props.note });
        }
    }

    onChange = (event) => {
        let stateData = this.state;
        stateData.note.data = event.target.value;
        this.setState(stateData);
        this.props.onEdit(this.state.note.id, this.state.note.data)
    }

    onKeyUp = (event) => {
        var element = typeof event === 'object' ? event.target : document.getElementById(event);
        var scrollHeight = element.scrollHeight - 50;
        element.style.height = scrollHeight + "px";
    }

    getMarkdownText() {
        const rawText = this.state.note.data;
        var rawMarkup = marked(rawText ? rawText : '', { sanitize: true });
        return { __html: rawMarkup };
    }

    fullScreen = () => {
        let toggle = this.state.toggle;
        this.setState({ toggle: !toggle })
    }

    render() {
        return (
            <div className="contain">
              
                { this.state.note !== null ?
                    <div id={this.state.toggle ? 'fullScreen' : 'halfScreen'}>
                          <button id='toggle' onClick={this.fullScreen}><img id={this.state.toggle ? 'untoggleIcon' : 'toggleIcon'} src={expand} alt='' /></button>
                        <div className="TextEditor">
                            {this.state.toggle ?
                                null : <p id='note-date'>Last modified on {this.state.note.date}</p>}
                            <textarea id='noteEditor' placeholder= 'Start typing...'
                                value={this.state.note.data}
                                onChange={this.onChange} />
                        </div>
                        <div id='wrap-preview'>
                            <article className="preview markdown" dangerouslySetInnerHTML={this.getMarkdownText()} />
                        </div>
                    </div>
                    : null}
            </div>
        );
    }
}

export default TextEditor;