import React, { Component } from 'react';
import Cards from '../components/cards/Cards';
import List from '../components/list/List';
import Nav from '../components/nav/Nav';
import './Home.css';


class Home extends Component {

    render() {
        let options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        return (
            <div>
                <div className="Head">
                    <span id='header'> The Ken</span>
                    <span id='date'>{new Intl.DateTimeFormat('en-US', options).format(new Date())}</span>
                </div>
                <Nav />
                <div className="Home">
                    <Cards />
                    <List />
                </div>
            </div>
        )
    }
}

export default Home;
