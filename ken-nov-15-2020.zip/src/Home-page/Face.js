import  React, {  } from 'react';
import './Face.css';

export default function Face() {

    return (
       
    <span style={{color: '#fff'}}><span className="Face">-<span className="Talk">_</span>-  </span>     Fuck off.....</span>
    )
}
