import React, { useState } from 'react';
import './App.css';
import List from './components/list/list';

export const ThemeContext = React.createContext();

function App() {
  const [theme, setTheme] = useState({
    currentTheme: 'Light',
    light: 'Light',
    dark: 'Dark',
    lightColor: '#fff',
    darkColor: 'rgb(78, 78, 78)',
    header: { light: '#dedede', dark: 'rgb(64, 64, 65)' },
    trayColor: { light: 'rgb(233, 233, 233)', dark: 'rgb(49, 48, 48)' },
    editorColor: { light: '#fff', dark: '#222' }
  })

  return (
    <div className="App">
      <ThemeContext.Provider value={[theme, setTheme]}>
        <header className="App-header" />
        <List />
      </ThemeContext.Provider>
    </div>
  );
}

export default App;
