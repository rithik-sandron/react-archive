import React, { useContext } from 'react';
import './header.css'
import { ThemeContext } from '../App';

export default function Header() {

    const [theme, setTheme] = useContext(ThemeContext);

    function toggleTheme() {
       theme.currentTheme = theme.currentTheme === theme.light ? theme.dark : theme.light;
       setTheme({...theme});
    }
    const backgroundColor = theme.currentTheme === theme.light ? theme.header.light : theme.header.dark;
    const color = theme.currentTheme === theme.light ? theme.darkColor : theme.lightColor;
    return (
        <div style={{ backgroundColor: backgroundColor, height: "6%", fontSize: "32px", color: color }}>
            <span style={{ paddingLeft: "16px" }}>Noted.</span>
            <button onClick={toggleTheme} className="themeToggle">{theme.currentTheme}</button>
        </div>


    )

}
